# ifndef GTK_BUTTON_FILE_H
# define GTK_BUTTON_FILE_H

# include "gtk_function.h"

// ������ ������� ������� ��������� ����
void file_button( GtkWidget *table )
{
	GtkWidget *button = gtk_label_new(" File: ");
	gtk_table_attach_defaults (GTK_TABLE (table), button, 0, 2, 0, 1);
	gtk_widget_show (button);

	button = gtk_button_new_with_label(" Open ");
	gtk_table_attach_defaults (GTK_TABLE (table), button, 2, 5, 0, 1);
	g_signal_connect(button, "clicked", G_CALLBACK(window_open_file), 0);
	gtk_widget_show (button);

	button = gtk_button_new_with_label(" Save and close ");
	gtk_table_attach_defaults (GTK_TABLE (table), button, 5, 8, 0, 1);
	g_signal_connect(button, "clicked", G_CALLBACK(window_save_file), 0);
	gtk_widget_show (button);
}

# endif
# ifndef DATA_H
# define DATA_H

# include <gtk/gtk.h>
# include <iostream>
# include <fstream>
# include <vector>
# include <conio.h>
# include "class_person.h"

using std::vector;
using std::ifstream;
using std::ofstream;
static  GtkTextBuffer *buffer;

int position = 1;
person_data* person_1 = new person_data();
person_data* person_2 = new person_data();

char file_name[103];
char str[10000];
char str1[10000];
ifstream r_file;
ofstream w_file;

vector<person_data> Stud;
vector<person_data> Univ;

# endif


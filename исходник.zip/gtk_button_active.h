# ifndef GTK_BUTTON_ACTIVE_H
# define GTK_BUTTON_ACTIVE_H

# include "gtk_function.h"

// ������ �������� � ����������
void action_button( GtkWidget *table )
{
	GtkWidget *button = gtk_label_new(" Work with the journal: ");
	gtk_table_attach_defaults (GTK_TABLE (table), button, 0, 2, 2, 3);
	gtk_widget_show (button);

	button = gtk_button_new_with_label(" Add ");
	gtk_table_attach_defaults (GTK_TABLE (table), button, 2, 4, 2, 3);
	g_signal_connect(button, "clicked", G_CALLBACK( add ), 0);
	gtk_widget_show (button);

	button = gtk_button_new_with_label(" Delete ");
	gtk_table_attach_defaults (GTK_TABLE (table), button, 4, 6, 2, 3);
	g_signal_connect(button, "clicked", G_CALLBACK( delet ), 0);
	gtk_widget_show (button);

	button = gtk_button_new_with_label(" Show ");
	gtk_table_attach_defaults (GTK_TABLE (table), button, 6, 8, 2, 3);
	g_signal_connect(button, "clicked", G_CALLBACK( show), 0);
	gtk_widget_show (button);

	GtkWidget *label = gtk_button_new_with_label(" Buffer ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 1, 7, 3, 4);
	g_signal_connect(label, "clicked", G_CALLBACK(convert), 0);
	gtk_widget_set_size_request(label, 100, 50);
	gtk_widget_show (label);
}

# endif
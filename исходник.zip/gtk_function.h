# ifndef GTK_FUNCTION_H
# define GTK_FUNCTION_H

# include "data.h"
# include "gtk_func_add.h"
// �������� ������
gint delete_event ( GtkWidget * widget, GdkEvent * event, gpointer data )
{
	gtk_main_quit ();
	return (FALSE);
}
// ��������� � ��������� ����
void func_file_name ( GtkWidget *entry )
{
  const gchar *entry_text;
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
  for( int i = 0; i < 100; i++ ) file_name[i] = entry_text[i];
  strcat(file_name, ".txt");
  r_file.open( file_name );

  std::string stroka;
  int s = -1;

  if( r_file.fail() ) std::cout << " Could not open file!!!\n";
  else {
	  while( !r_file.eof() )
	  {
		  r_file >> stroka;
		  s++;
	  }
	  int i = 0;
	  if( s > 0 )
	  {
		  std::cout << " File is not empty!!!\n";
		  r_file.seekg( 0, r_file.beg );
		  while( !r_file.eof() )
		  {
			  r_file >> stroka;
			  person_1->setData_1( stroka );
			  r_file >> stroka;
			  person_1->setData_2( stroka );
		      r_file >> i;
			  person_1->setData_3( i );
			  r_file >> stroka;
			  person_2->setData_1( stroka );
			   r_file >> stroka;
			  person_2->setData_2( stroka );
			   r_file >> i;
			  person_2->setData_3( i );
			  Stud.push_back( person_1[0] );
			  Univ.push_back( person_2[0] );
		  }
	  }
	  else std::cout << " File is empty!!!\n";
  }
  r_file.close();
}

// ���� �����
void _entry( GtkWidget *entry_box, void func(GtkWidget*) )
{
	GtkWidget *entry;
	entry = gtk_entry_new ();
    gtk_entry_set_max_length (GTK_ENTRY (entry), 100);
    g_signal_connect (G_OBJECT (entry), "activate", G_CALLBACK ( func ),(gpointer) entry);
    gtk_editable_select_region (GTK_EDITABLE (entry), 0, GTK_ENTRY (entry)->text_length);
    gtk_box_pack_start (GTK_BOX (entry_box), entry, TRUE, TRUE, 0);
    gtk_widget_show (entry);
}

// ���������� ���� - ���� �������� �����
void window_open_file()
{
	GtkWidget *dialog = gtk_dialog_new_with_buttons (" Journal -> Open file ", NULL, GTK_DIALOG_DESTROY_WITH_PARENT, "Close", NULL, NULL);
    g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);
	gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(dialog, 250, 75);

	GtkWidget *table = gtk_table_new (1, 4, TRUE);  

	GtkWidget *label = gtk_label_new(" Enter the file name: ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 0, 2, 0, 1); 
	gtk_widget_show (label);

	label = gtk_vbox_new (FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (table), label, 2, 4, 0, 1);
	_entry( label, func_file_name );
	gtk_widget_show (label);

	gtk_container_add (GTK_CONTAINER (GTK_DIALOG(dialog)->vbox), table);
	gtk_widget_show_all (dialog);
}

// ���������� ���� - ���������
void window_save_file()
{
	GtkWidget *dialog = gtk_dialog_new_with_buttons (" Journal -> Save file ", NULL, GTK_DIALOG_DESTROY_WITH_PARENT, GTK_STOCK_OK, GTK_RESPONSE_NONE, NULL);
    g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);
	gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(dialog, 250, 75);
	GtkWidget *label = gtk_label_new(" The file is saved and closed! ");
	gtk_container_add (GTK_CONTAINER (GTK_DIALOG(dialog)->vbox), label);
	gtk_widget_show_all (dialog);
	w_file.open( file_name );
	w_file << str1;
	w_file.close();
}
// ��������
void add()
{
	GtkWidget *dialog, *table;
	dialog = gtk_dialog_new_with_buttons (" Journal ->  Add ", NULL, GTK_DIALOG_DESTROY_WITH_PARENT, NULL, GTK_RESPONSE_NONE, NULL);
    g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);
	gtk_widget_set_size_request(dialog, 500, 175);
	gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);
	table = gtk_table_new (3, 8, TRUE);  

	GtkWidget *label = gtk_label_new(" #: ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 0, 1, 0, 1);
	GtkWidget *entry_box = gtk_vbox_new (FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (table), entry_box, 1, 2, 0, 1);
	_entry( entry_box, number );
	gtk_widget_show (label);

	label = gtk_label_new(" Surname: ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 2, 3, 0, 1);
	gtk_widget_show (label);

	entry_box = gtk_vbox_new (FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (table), entry_box, 3, 5, 0, 1);
	_entry( entry_box, surname );

	label = gtk_label_new(" Name: ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 5, 6, 0, 1);
	gtk_widget_show (label);

	entry_box = gtk_vbox_new (FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (table), entry_box, 6, 8, 0, 1);
	_entry( entry_box, name );

	label = gtk_label_new(" Year: ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 0, 1, 1, 2);
	gtk_widget_show (label);

	entry_box = gtk_vbox_new (FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (table), entry_box, 1, 2, 1, 2);
	_entry( entry_box, year );
	
	label = gtk_label_new(" Faculty: ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 2, 3, 1, 2);
	gtk_widget_show (label);

	entry_box = gtk_vbox_new (FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (table), entry_box, 3, 5, 1, 2);
	_entry( entry_box, faculty );

	label = gtk_label_new(" Group: ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 5, 6, 1, 2);
	gtk_widget_show (label);

	entry_box = gtk_vbox_new (FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (table), entry_box, 6, 8, 1, 2);
	_entry( entry_box, group );

	label = gtk_label_new(" Rating: ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 0, 2, 2, 3);
	gtk_widget_show (label);

	entry_box = gtk_vbox_new (FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (table), entry_box, 2, 7, 2, 3);
	_entry( entry_box, rating );

	label = gtk_button_new_with_label(" Save ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 2, 6, 3, 4);
	g_signal_connect(label, "clicked", G_CALLBACK(save), 0);
	gtk_widget_show (label);

	gtk_container_add (GTK_CONTAINER (GTK_DIALOG(dialog)->vbox), table);
	gtk_widget_show_all (dialog);
}

void delet()
{
	GtkWidget *dialog, *table;
	dialog = gtk_dialog_new_with_buttons (" Journal ->  Delete ", NULL, GTK_DIALOG_DESTROY_WITH_PARENT, NULL, GTK_RESPONSE_NONE, NULL);
    g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);
	gtk_widget_set_size_request(dialog, 300, 100);
	gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);
	table = gtk_table_new (2, 2, TRUE);  

	GtkWidget *label = gtk_label_new(" #: ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 0, 3, 0, 1);
	GtkWidget *entry_box = gtk_vbox_new (FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (table), entry_box, 3, 8, 0, 1);
	_entry( entry_box, number );
	gtk_widget_show (label);

	label = gtk_button_new_with_label(" Delete ");
	gtk_table_attach_defaults (GTK_TABLE (table), label, 2, 6, 1, 2);
	g_signal_connect(label, "clicked", G_CALLBACK(del), 0);
	gtk_widget_show (label);

	gtk_container_add (GTK_CONTAINER (GTK_DIALOG(dialog)->vbox), table);
	gtk_widget_show_all (dialog);
}

void print()
{
	for ( int i = 0; i < Stud.size(); i++)
		std::cout << Stud[i].getData_1() << " " << Stud[i].getData_2() << " "<< Stud[i].getData_3() << " " << Univ[i].getData_1() << " " << Univ[i].getData_2() << " " << Univ[i].getData_3() << "\n";
}

void convert()
{

	char n[100];
	char m[100];
	for(int i = 0; i < 10000; i++)
	{
		str[i] = '\0';
		str1[i] = '\0';
	}
	for(int i = 0; i < Stud.size(); i++)
	{
		std::strcat(str, "# ");
		sprintf(m, "%d", i+1);
		std::strcat(str, m );

		std::strcat(str, " Surname: " );
		for( int k = 0; k < Stud[i].getData_1().size() + 1; k++)
			n[k] = Stud[i].getData_1()[k];
		std::strcat(str, n );
		std::strcat(str1, n);
		std::strcat(str1, "\n");
		std::strcat(str, " Name: " );
		for( int k = 0; k < Stud[i].getData_2().size() + 1; k++)
			n[k] = Stud[i].getData_2()[k];
		std::strcat(str, n );
		std::strcat(str1, n);
		std::strcat(str1, "\n");
		std::strcat(str, " Year " );
		sprintf(m, "%d", Stud[i].getData_3());
		std::strcat(str, m );
		std::strcat(str1, m);
		std::strcat(str1, "\n");
		std::strcat(str, " Faculty: " );
		for( int k = 0; k < Univ[i].getData_1().size() + 1; k++)
			n[k] = Univ[i].getData_1()[k];
		std::strcat(str, n );
		std::strcat(str1, n);
		std::strcat(str1, "\n");
		std::strcat(str, " Group: " );
		for( int k = 0; k < Univ[i].getData_2().size() + 1; k++)
			n[k] = Univ[i].getData_2()[k];
		std::strcat(str, n );
		std::strcat(str1, n);
		std::strcat(str1, "\n");
		std::strcat(str, " Rating: " );
		sprintf(m, "%d", Univ[i].getData_3());
		std::strcat(str, m );
		std::strcat(str, "\n" );
		std::strcat(str1, m);
		std::strcat(str1, "\n");
	}
}
void show()
{
	GtkWidget *dialog = gtk_dialog_new_with_buttons (" Journal -> Show file ", NULL, GTK_DIALOG_DESTROY_WITH_PARENT, NULL, NULL, NULL);
    g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);
	gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(dialog, 500, 350);
	GtkWidget *table = gtk_table_new (1, 2, TRUE); 
	GtkWidget *textview = gtk_text_view_new();
        //~ ��, ��� ������ � �������
        //~ ������ �������� �� ���������� � ���� GtkTextView
    buffer=gtk_text_view_get_buffer( (GtkTextView *) textview );
	gtk_text_buffer_set_text(buffer, str, -1);

	gtk_table_attach_defaults (GTK_TABLE (table),textview, 0, 3, 0, 1);
	gtk_container_add (GTK_CONTAINER (GTK_DIALOG(dialog)->vbox), table);
	gtk_widget_show_all (dialog);
}

# endif
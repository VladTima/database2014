# ifndef GTK_FUNC_ADD_H
# define GTK_FUNC_ADD_H

# include "data.h"

// �������
void number( GtkWidget *entry )
{
	const gchar *entry_text;
	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
	std::string s = entry_text;
	position = atoi(s.c_str());
}
// �������
void surname( GtkWidget *entry )
{
	const gchar *entry_text;
	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
	person_1->setData_1( entry_text );
}
// ���
void name( GtkWidget *entry )
{
	const gchar *entry_text;
	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
	person_1->setData_2( entry_text );
}
// ���
void year( GtkWidget *entry )
{
	const gchar *entry_text;
	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
	person_1->setData_3( atoi(entry_text) );
}
// ���������
void faculty( GtkWidget *entry )
{
	const gchar *entry_text;
	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
	person_2->setData_1( entry_text );
}
// ������
void group( GtkWidget *entry )
{
	const gchar *entry_text;
	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
	person_2->setData_2( entry_text );
}
// �������
void rating( GtkWidget *entry )
{
	const gchar *entry_text;
	entry_text = gtk_entry_get_text (GTK_ENTRY (entry));
	person_2->setData_3( atoi(entry_text) );
}
// ���������
void save()
{
	if( Stud.size() != 0 ) 
	{
		Stud.insert(Stud.begin() + position - 1, person_1[0]);
		Univ.insert(Univ.begin() + position - 1, person_2[0]);
		std::cout << "Saved! ";
	}
	else std::cout << "No Saved! ";
}
// �������
void del()
{
	if( Stud.size() != 0 ) 
	{
		Stud.erase( Stud.begin() + position - 1 );
		Univ.erase( Univ.begin() + position - 1 );
		std::cout << "Delete! ";
	}
	else std::cout << "No Delete! ";
}
# endif
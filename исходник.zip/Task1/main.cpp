# include "data_students.h"
#include <conio.h>
#include <process.h>
#include <dos.h>
#include <iostream>
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <tchar.h>

Students theStudents("database.bin");
int n = 1;
void gotoxy(int x, int y)
{
    COORD ord;
    ord.X = x;
    ord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), ord); 
}


int DisplayMainMenu()
{
    ::system("cls");
    
    gotoxy(10,4);
    std::cout << "Welcome to Student Database Application";

    gotoxy(10,5);
    std::cout << "___________________________________________";

    gotoxy(10,6);
    std::cout << "1. Add Student Record";

    gotoxy(10,7);
    std::cout << "2. Edit Student Record";

    gotoxy(10,8);
    std::cout << "3. View Student Record";

    gotoxy(10,9);
    std::cout << "4. Delete Student Record";

    gotoxy(10,10);
    std::cout << "5. Exit";

    gotoxy(10,11);
    std::cout << "___________________________________________";

    gotoxy(10,13);
    std::cout << "Enter your Selection: ";
    int m = -1;
    std::cin >> m;

    return m;
}

void ViewRecords()
{
    theStudents.ReadRecords();
    
    ::system("cls");
        
    gotoxy(10,4);
    std::cout << "Welcome to Student Database Application";

    gotoxy(10,5);
    std::cout << "___________________________________________";

    gotoxy(10,6);
    std::cout << "SNo Student Name       Age    Department   ";

    gotoxy(10,7);
    std::cout << "___________________________________________";

    int pos = 8;
    // Enable Paging
    for(int i = 0; i < (int)theStudents.St.size(); i++)
    {
        gotoxy(10,pos);
        std::cout << i + 1;
        gotoxy(14,pos);
        std::cout << theStudents.St[i].getName();
        gotoxy(33,pos);
        std::cout << theStudents.St[i].getAge();
        gotoxy(42,pos);
		std::cout << theStudents.St[i].getDept();
        pos++;
    }
    gotoxy(10,pos++);
    std::cout << "___________________________________________";
    pos++;
    gotoxy(10,pos++);
}


void InputRecords()
{
    while(1)
    {
        ::system("cls");
        
        gotoxy(10,4);
        std::cout << "Welcome to Student Database Application";

        gotoxy(10,5);
        std::cout << "___________________________________________";

        gotoxy(10,6);
        std::cout << "Student Name: ";

        gotoxy(10,7);
        std::cout << "Age: ";

        gotoxy(10,8);
        std::cout << "Departement: ";

        gotoxy(10,9);
        std::cout << "___________________________________________";

        gotoxy(23,6);
        char name[64];
        std::cin >> name;

        gotoxy(17,7);
        int age;
        std::cin >> age;

        gotoxy(23,8);
        char dept[64];
        std::cin >> dept;

        theStudents.AddRecord(name, age, dept);

        gotoxy(10,11);
        std::cout << "Do you want to add another record (Y/N)? ";
        char ch = getch();

        if(ch == 'Y' || ch == 'y')
            continue;
        else
            break;
    }
}


void EditRecords()
{
    ViewRecords();
    std::cout << "Enter the serial number you want to edit: ";
    int m;
    std::cin >> m;

    if(m >= 1 && m <= theStudents.St.size())
    {
        ::system("cls");
        gotoxy(10,4);
        std::cout << "Welcome to Student Database Application";

        gotoxy(10,5);
        std::cout << "___________________________________________";

        gotoxy(10,6);
        std::cout << "Student Name: ";

        gotoxy(10,7);
        std::cout << "Age: ";

        gotoxy(10,8);
        std::cout << "Departement: ";

        gotoxy(10,9);
        std::cout << "___________________________________________";

        gotoxy(23,6);
        char name[64];
        std::cin >> name;

        gotoxy(17,7);
        int age;
        std::cin >> age;

        gotoxy(23,8);
        char dept[64];
        std::cin >> dept;

        theStudents.EditRecord(m - 1, name, age, dept);        
        gotoxy(10,12);
        std::cout << "Record updated. Press any key to return to Main Menu";
        char ch = getch();
    }
    else
    {
        gotoxy(10,12);
        std::cout << "Invalid Entry. Press any key to return to Main Menu";
        char ch = getch();
    }

}

void DeleteRecords()
{
    ViewRecords();
    std::cout << "Enter the serial number you want to delete: ";
    int m;
    std::cin >> m;
    if(m >= 1 && m <= theStudents.St.size())
    {
        theStudents.DeleteRecord(m - 1);
        std::cout << "          Record deleted. Press any key to return to Main Menu";
        char ch = getch();
    }
    else
    {
        std::cout << "          Invalid Entry. Press any key to return to Main Menu";
        char ch = getch();
    }
}

int _tmain(int argc, _TCHAR* argv[])
{
    theStudents.ReadRecords();
    while(1)
    {
        int selection = DisplayMainMenu();

        switch(selection)
        {
        case 1:
            InputRecords();
            break;
        case 2:
            EditRecords();
            break;
        case 3:
            {
            ViewRecords();
            std::cout << "Press any key to return to Main Manu: ";
            char ch = getch();
            }
            break;
        case 4:
            DeleteRecords();
            break;

        case 5:
        default:
            return 0;
        };
    }
	return 0;
}
# ifndef DATA_STUDENTS_H
# define DATA_STUDENTS_H

# include <iostream>
# include <vector>
# include "data_univer.h"
class Students
{
public:
	char m_fileName[1024];
	int n;
	std::vector<Univer> St;
	Students(const char *filename) 
    { 
		n = 1;
        strcpy(m_fileName, filename);
    };

	void AddRecord( const char *name, int age, const char *dept )
    {
        Univer* A = new Univer();
		A->setAge( age );
		A->setName( name );
		A->setDept( dept );
		St.push_back( A[0] );
        WriteRecords();
		return;
    }

	void EditRecord( int pos, const char *name, int age, const char *dept )
    {
		St.erase( St.begin() + pos - 1 );
		Univer* A = new Univer();
		A->setAge( age );
		A->setName( name );
		A->setDept( dept );
		St.insert(St.begin() + pos - 1, A[9] );
        WriteRecords();
    }
	void DeleteRecord( int pos )
	{
	    St.erase( St.begin() + pos - 1 );
        WriteRecords();
	}

	 int ReadRecords()
     {
		 FILE *istream = fopen(m_fileName, "rb");
		 if (istream == 0) return false;
		 
		 char buf[4096];
         int nTotalRecordsRead = 0;
		 if( n != 1 ) return false;
		 n--;
         for(int i = 0; i < (int)St.size()+1; i++)
         {
             if(feof(istream))
                  break;
             int nBytesRead = fread(buf, 1, sizeof(Univer), istream);
             if(nBytesRead < sizeof(Univer))
                  break;
			 Univer A;
             char *p = reinterpret_cast<char*>(&A);
             memcpy(p, buf, sizeof(Univer));
			 St.push_back(A);
             nTotalRecordsRead++;
          }
        
        fclose(istream);
		return nTotalRecordsRead;
    };
	  int WriteRecords()
      {
        FILE *ostream = fopen(m_fileName, "wb");

        if (ostream == 0)
            return false;

        int nTotalRecordsWritten = 0;
        char buf[4096];
        for(int i = 0; i < St.size(); i++)
        { 
            fwrite((char*)&St[i], 1, sizeof(Univer), ostream);
            nTotalRecordsWritten++;
        }

        fclose(ostream);

        return nTotalRecordsWritten;
    }
};
# endif
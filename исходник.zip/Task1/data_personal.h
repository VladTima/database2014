# ifndef DATA_PERSONAL_H
# define DATA_PERSONAL_H

class Personal
{
public:
	char name[50];
	int age;
	Personal(){};
	Personal( char* name, int age )
	{
		this->age = age;
		for( int i = 0; i < 50; ++i )
			this->name[i] = name[i];
	};
	Personal( const Personal &A )
	{
		this->age = A.age;
		for( int i = 0; i < 50; ++i )
			this->name[i] = A.name[i];
	};
	char* getName( void )
	{
		char* name = new char[ 50 ];
		for( int i = 0; i < 50; ++i )
			name[i] = this->name[i];
		return name;
	};
	int getAge( void )
	{
		return this->age;
	};
	void setName( const char* name )
	{
		for( int i = 0; i < 50; ++i )
			this->name[i] = name[i];
	};
	void setAge( const int age )
	{
		this->age = age;
	};
};

# endif

# ifndef DATA_UNIVER_H
# define DATA_UNIVER_H
# include "data_personal.h"

class Univer:public Personal
{
public:
	char dept[100];
	Univer():Personal(){};
	Univer( char *name, int age, char *dept ): Personal( name, age )
	{
		for( int i = 0; i < 100; ++i )
			this->dept[i] = dept[i];
	};
	Univer( const Univer &A ):Personal( A )
	{
		for( int i = 0; i < 100; ++i )
			this->dept[i] = A.dept[i];
	};
	char* getDept( void )
	{
		char* name = new char[ 100 ];
		for( int i = 0; i < 100; ++i )
			dept[i] = this->dept[i];
		return dept;
	};
	void setDept( const char* dept )
	{
		for( int i = 0; i < 100; ++i )
			this->dept[i] = dept[i];
	};
};

# endif